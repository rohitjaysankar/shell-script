#!/bin/bash
echo -n "enter the target file "
read tar
cat fol.sh>>$tar
