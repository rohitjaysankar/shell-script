#!/bin/bash
a=1
b=2
while [ true ]
do
   mkdir -p {$a$b}
   a=$b
   b=`expr $b + 1`
done
