#!/bin/bash
read -p 'Username:' username
read -sp 'password' password
echo Welcome $username

