#!/bin/bash
let a=$1+30
echo $a

