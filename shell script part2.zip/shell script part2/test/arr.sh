#!/bin/bash
echo enter the array
read -a list
echo enter the search element
read x
for i in "$[list[@]]"
do
   if[$i = $x];
  then
        flag=0
        break
    else
        flag=1
    fi
done

if[ $flag=0]
then
   echo the element is present
else
   echo the element is not present
fi

