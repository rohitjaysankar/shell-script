#!/bin/bash
echo hello World



#!/bin/bash
mkdir folder_test

