#!/bin/bash
mkdir folder_test
