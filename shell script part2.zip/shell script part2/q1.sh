#!/bin/bash
find test -name "*.sh"
